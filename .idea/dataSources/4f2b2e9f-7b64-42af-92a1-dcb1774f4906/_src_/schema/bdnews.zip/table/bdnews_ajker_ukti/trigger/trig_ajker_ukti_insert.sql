CREATE TRIGGER trig_ajker_ukti_insert
BEFORE INSERT ON bdnews_ajker_ukti
FOR EACH ROW
  BEGIN
IF NEW.ts='0000-00-00 00:00:00' THEN
        SET NEW.ts = CURRENT_TIMESTAMP;
        END IF;
END;
