CREATE TRIGGER trig_slider_pics_update
BEFORE UPDATE ON bdnews_slider_pics
FOR EACH ROW
  BEGIN
IF NEW.ts='0000-00-00 00:00:00' THEN
        SET NEW.ts = CURRENT_TIMESTAMP;
        END IF;
END;
